OBIDO OS PWA

طريقة النشر:
1. ارفع جميع الملفات إلى أي Hosting يدعم HTTPS مثل Netlify أو Vercel أو Firebase Hosting.
2. افتح الرابط في Safari على iPhone.
3. اختر Partilhar / Share.
4. اختر Adicionar ao ecrã principal / Add to Home Screen.
5. سيظهر OBIDO OS كتطبيق مستقل بأيقونته.

الدخول التجريبي:
Email: أي بريد
Password: أي كلمة

مهم:
هذه النسخة تحفظ البيانات محلياً داخل الجهاز.
المرحلة التالية للإنتاج الحقيقي: قاعدة بيانات سحابية، حسابات مستخدمين، نسخ احتياطي، فواتير قانونية، وربط البريد وOpenAI.
